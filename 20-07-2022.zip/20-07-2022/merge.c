#include<stdio.h>
#include<conio.h>
#include<time.h>


void mergesort(int a[],int low,int high);
void merge(int a[],int low,int mid,int high);


void delay(){
    long l;
    int temp;
    for(l=0;l<1000000;l++)
        temp=100/110;
}

int main(){
    double start,end;
    int arr[150],n=10,i,low=0;
/*
    printf("Enter no of elements:");
    scanf("%d",&n);

    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }

    mergesort(arr,0,n-1);

    printf("\n The Sorted array is: ");
    for(i=0;i<n;i++){
        printf("%d\t",arr[i]);
    }

*/

    while(n<=150){
        for(i=n;i>0;i--)
            arr[i-1] = i;


        start=clock();
        mergesort(arr,0,n-1);
        end=clock();

        printf("for n = %d time = %f \n",n,(end-start)/CLOCKS_PER_SEC);

        n=n+10;
    }


}

void mergesort(int a[],int low,int high){
    int mid;
    if(low<high){
        mid=(low+high)/2;
        mergesort(a,low,mid);
        mergesort(a,mid+1,high);
        merge(a,low,mid,high);
    }
}

void merge(int a[],int low,int mid,int high){
    int i,j,k,c[100];
    i=low;
    k=low;
    j=mid+1;

    while(i<=mid && j<=high){
        if(a[i]<a[j]){
            delay();
            c[k++]=a[i++];
        }
        else
            c[k++]=a[j++];
    }

    while(i<=mid)
        c[k++]=a[i++];
    while(j<=high)
        c[k++]=a[j++];

    for(i=low;i<=high;i++)
        a[i]=c[i];
}




