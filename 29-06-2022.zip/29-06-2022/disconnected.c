#include <stdio.h>
#include <conio.h>

int arr[10][10],vis[10],n;

void DFS(int);

int main(){
    int i,j,src;
    printf("Enter no of vertices:");
    scanf("%d",&n);


    printf("Enter adjacency matrix:\n");

    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            printf("Connection between vertex %d and %d:",i,j);
            scanf("%d",&arr[i][j]);
        }
    }

    for(i=1;i<=n;i++){
        vis[i]=0;
    }

    DFS(1);

    int flag=0;

    for(i=1;i<=n;i++){
        if(vis[i]==0)
            flag=1;
    }


    if(flag==1)
        printf("Graphs are disconnected\n");

    else
        printf("Graphs are connected\n");
}


void DFS(int v){
    int i;
    vis[v]=1;
    printf("%d ",v);

    for(i=1;i<=n;i++){
        if(arr[v][i]==1 && vis[i]==0){
            DFS(i);
        }
    }
}
