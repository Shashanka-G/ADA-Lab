#include <stdio.h>
#include<conio.h>
#include<time.h>

void delay(){
    int i,temp;
    for(i=0;i<500000;i++)
        temp=100/110;
}


int lsearch(int arr[],int start,int key,int size){
    delay();

    if(start>size)
        return -1;
    else if(arr[start]==key)
        return 1;
    else
        return lsearch(arr,start+1,key,size);
}

int binsearch(int arr[],int high,int low,int key){

    delay();

    int mid = (high+low)/2;

    if(low>high)
        return -1;

    else if(key==arr[mid])
        return 1;

    else if(key>arr[mid]){
        low=mid+1;
        return binsearch(arr,high,low,key);
    }

    else{
        high=mid-1;
        return binsearch(arr,high,low,key);
    }

}

int main(){
    int arr[100000];
    int j,i,choice,key,n,found=-1;
    double start,end;

    printf("1.Linear search 2.Binary search \nSelect choice:");
    scanf("%d",&choice);

    switch(choice){

    case 1:

        n=1000;
        while(n<=10000){
            for(i=0;i<n;i++)
                arr[i]=i;

            key = arr[n-1];

            start=clock();

            found=lsearch(arr,0,key,n);

            end=clock();

            if(found==1)
                printf("Element is found ");
            else
                printf("Element not found ");

            printf("time for n=%d is %.4f seconds \n",n,((end-start)/CLOCKS_PER_SEC));

            n=n+1000;
        }


        break;

    case 2:
        n=1000;
        while(n<15000){
            for(i=0;i<n;i++)
                arr[i]=i;

            key = -1;

            start=clock();
            found=binsearch(arr,n,0,key);
            end=clock();

            if(found==-1)
                printf("Key not found ");
            else
                printf("Key found ");

            printf("time for n=%d is %f \n",n,((end-start)/CLOCKS_PER_SEC));

            n=n+1000;
        }
    }
}
