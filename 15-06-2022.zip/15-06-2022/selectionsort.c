#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void delay(){
    long n;
    for(n=0;n<10;n++){
        int a = 10/10;
    }
}

void ssort(int arr[],int length){
    int i,j;
    for(i=0;i<=length-2;i++){
        int max=i;
        for(j=i+1;j<=length-1;j++){
            if(arr[j]>arr[max]){
                max=j;
                delay();
            }
        }

        {
            int temp=arr[max];
            arr[max]=arr[i];
            arr[i]=temp;
        }
    }
}

int main(){

    int arr[15000],n=1000,i,k;
    double start,end;

    while(n<=15000){
        for(i=0;i<n;i++){
            arr[i]=i;
           // printf("%d ",arr[i]);
        }

        start = clock();
        ssort(arr,n);
        end=clock();

        printf("n=%d  time= %f \n",n,(end-start)/CLOCKS_PER_SEC);

        for(k=0;k<n;k++){
            //printf("%d ",arr[k]);
        }
        printf("\n");

        n=n+1000;



    }
}
