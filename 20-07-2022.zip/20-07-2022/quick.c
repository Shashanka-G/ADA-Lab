#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int partition(int a[],int low,int high){
    int i,j,temp,pivot;
    pivot=a[low];
    i=low+1;
    j=high;

    while(i<=j){
        while(a[i]<=pivot)
            i++;
        while(a[j]>pivot)
            j--;
        if(i<j){
            temp=a[i];
            a[i]=a[j];
            a[j]=temp;
        }
    }

    temp=a[low];
    a[low]=a[j];
    a[j]=temp;
    return j;
}

void QuickSort(int a[],int low,int high){
    int mid;
    if(low<high){
        mid=partition(a,low,high);
        QuickSort(a,low,mid-1);
        QuickSort(a,mid+1,high);
    }
}


int main(){
    double start,end;
    int arr[15000],n=1000,i;

    while(n<=15000){
        for(i=0;i<n;i++)
            arr[i]=i;
        start=clock();
        QuickSort(arr,0,n-1);
        end=clock();
        printf("for n = %d time = %f \n",n,(end-start)/CLOCKS_PER_SEC);
        n=n+1000;
    }


/*  printf("No of elements:");
    scanf("%d",&n);

    for(i=0;i<n;i++){
        printf("arr[%d]=",i);
        scanf("%d",&arr[i]);
    }
    QuickSort(arr,0,n-1);
    for(i=0;i<n;i++){
        printf("%d ",arr[i]);
    }

*/
}
