#include<stdio.h>
#include<conio.h>
#include<time.h>

void delay(){
    int i,temp;
    for(i=0;i<1500000;i++){
        temp=33/550;
    }
}

int main(){
    int a[60000];
    int j,i,c,key,n,o=-1;
    double start,end;

    printf("1.Linear search 2.Binary search\nSelect choice:");
    scanf("%d",&c);

    if(c==1){
        n=1000;
        while(n<=10000){
            for(i=0;i<n;i++)
                a[i]=i;

            key=a[n-1];
            start = clock();

            for(i=0;i<1000;i++){
                delay();
                if(a[i]==key)
                    o=0;
            }

            end=clock();

            if(o==0)
                printf("Element is found");
            else
                printf("Element not found\n");

            printf("  time for n=%d is %2f secs\n",n,((end-start)/CLOCKS_PER_SEC));
            n=n+1000;
        }
    }
    else if(c==2){
        n=1000;
        while(n<=15000){
            for(i=0;i<n;i++){
                a[i]=i;
            }
            key=a[n-1];
            double start = clock();

            {
                int b,m,e;
                b=0;e=n-1;
                while(b<=e){
                    m=(b+e)/2;
                    delay();
                    if(a[m]==key){
                        o=0;
                        break;
                    }
                    else if(a[m]<key)
                        b=m+1;
                    else if(a[m]>key)
                        e=m-1;
                }

                if(o==0)
                    printf("Element is found  ");
                else
                    printf("Element not found\n");

                double end=clock();
                printf("time for n=%d id %2f secs\n",n,((end-start)/CLOCKS_PER_SEC));
                n=n+1000;

            }

            }
        }
}

