#include<stdio.h>

int GCD(int m, int n){
    if(n==0)
        return m;
    else{
        int r=m%n;
        return GCD(n,r);
    }
}

int main(){
    int n,m,gcd;
    printf("Enter m:");
    scanf("%d",&m);
    printf("Enter n:");
    scanf("%d",&n);
    gcd=(m>=n?GCD(m,n):GCD(n,m));
    printf("GCD of %d and %d is %d\n",m,n,gcd);
}
