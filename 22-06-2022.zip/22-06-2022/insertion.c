#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void delay(){
    long l;
    int temp;
    for(l=0;l<100;l++)
        temp=100/110;
}

int isort(int arr[],int length){

    int i,j,val;

    for(i=1;i<length;i++){
        val=arr[i];

        j=i-1;

        while(j>=0 && arr[j]>val){
            arr[j+1]=arr[j];
            j-=1;
            delay();
        }

        arr[j+1]=val;
    }
}

int main(){
    double start,end;
    int arr[15000],n=1000,i;

    while(n<=15000){

        for(i=n;i>0;i--)
            arr[i] = n-i;

        start=clock();

        isort(arr,n);

        end=clock();

        printf("for n=%d time=%f \n",n,(end-start)/CLOCKS_PER_SEC);

        n=n+1000;
    }


/*
    for(i=0;i<10;i++){
        scanf("%d",&arr[i]);
    }

    start=clock();
    isort(arr,10);
    end=clock();

    printf("for n=%d time=%f \n",10,(end-start)/CLOCKS_PER_SEC);

    for(i=0;i<10;i++)
        printf("%d ",arr[i]);
*/

}
